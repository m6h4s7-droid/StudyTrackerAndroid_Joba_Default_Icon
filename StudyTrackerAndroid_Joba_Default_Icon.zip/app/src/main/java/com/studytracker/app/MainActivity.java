package com.studytracker.app;

import android.app.Activity;
import android.content.Intent;
import android.content.ComponentName;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.content.SharedPreferences;
import android.widget.Toast;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final int CREATE_BACKUP = 4101;
    private static final int OPEN_BACKUP = 4102;
    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private String pendingBackup = null;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(9, 6, 9));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(9, 6, 9));
        webView = new WebView(this);
        if (android.os.Build.VERSION.SDK_INT >= 30) getWindow().setDecorFitsSystemWindows(true);
        setContentView(webView);
        DailyGoalAlarmReceiver.scheduleNext(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        webView.setBackgroundColor(android.graphics.Color.rgb(9, 6, 9));
        webView.addJavascriptInterface(new NativeBridge(), "StudyTrackerNative");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                String[] accepted = params.getAcceptTypes();
                String mime = "*/*";
                if (accepted != null) {
                    for (String type : accepted) {
                        if (type != null && !type.trim().isEmpty()) { mime = type; break; }
                    }
                }
                intent.setType(mime);
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                startActivityForResult(intent, OPEN_BACKUP);
                return true;
            }
        });
        webView.loadUrl("file:///android_asset/index.html");
    }

    private class NativeBridge {
        @JavascriptInterface public String getSyncedState() {
            return getSharedPreferences("study_tracker_native", MODE_PRIVATE).getString("synced_state", null);
        }
        @JavascriptInterface public void syncState(String json) {
            getSharedPreferences("study_tracker_native", MODE_PRIVATE).edit().putString("synced_state", json).apply();
        }
        @JavascriptInterface public void setLauncherIcon(String logo, String flowerColor) {
            runOnUiThread(() -> applyLauncherIcon(logo, flowerColor));
        }
        @JavascriptInterface public void saveBackup(String json) {
            runOnUiThread(() -> {
                pendingBackup = json;
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                intent.putExtra(Intent.EXTRA_TITLE, "study-tracker-backup.json");
                startActivityForResult(intent, CREATE_BACKUP);
            });
        }
    }


    private void applyLauncherIcon(String logo, String flowerColor) {
        String suffix = "joba".equals(logo) ? "joba_" + (flowerColor == null ? "red" : flowerColor) : logo;
        String[] ids = {"atom","cap","book","brain","trophy","flask","bulb","target","spark","crown","joba_red","joba_black","joba_white","joba_yellow"};
        PackageManager pm = getPackageManager();
        String selected = ".Launcher" + suffix.substring(0,1).toUpperCase() + suffix.substring(1);
        for (String id : ids) {
            String alias = ".Launcher" + id.substring(0,1).toUpperCase() + id.substring(1);
            try {
                pm.setComponentEnabledSetting(new ComponentName(this, getPackageName() + alias),
                    alias.equals(selected) ? PackageManager.COMPONENT_ENABLED_STATE_ENABLED : PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                    PackageManager.DONT_KILL_APP);
            } catch (Exception ignored) { }
        }
        getSharedPreferences("launcher", MODE_PRIVATE).edit().putString("icon", suffix).apply();
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CREATE_BACKUP) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingBackup != null) {
                try (OutputStream out = getContentResolver().openOutputStream(data.getData())) {
                    out.write(pendingBackup.getBytes(StandardCharsets.UTF_8));
                    Toast.makeText(this, "Backup saved", Toast.LENGTH_SHORT).show();
                } catch (Exception e) { Toast.makeText(this, "Backup save failed", Toast.LENGTH_LONG).show(); }
            }
            pendingBackup = null;
        } else if (requestCode == OPEN_BACKUP) {
            if (fileCallback != null) {
                Uri[] result = (resultCode == RESULT_OK && data != null && data.getData() != null) ? new Uri[]{data.getData()} : null;
                fileCallback.onReceiveValue(result);
                fileCallback = null;
            }
        }
    }

    @Override public void onBackPressed() {
        if (webView != null) webView.evaluateJavascript("window.appBack && window.appBack()", null);
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (webView != null) { webView.removeJavascriptInterface("StudyTrackerNative"); webView.destroy(); }
        super.onDestroy();
    }
}
